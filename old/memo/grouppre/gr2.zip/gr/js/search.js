"use strict";
import { pages, keyWords } from "./searchTextInput.js";

const searchResult = document.getElementById("searchResult");
const searchResultNum = document.getElementById("searchResultNum");
const searchInput = document.getElementById("searchInput");
const suggestion = document.getElementById("suggestion");
const categoryBtn = document.querySelectorAll(".category-btn");

// 文字で検索機能
searchInput.addEventListener("input", function () {
  // 入力文字取得
  const word = searchInput.value.toLowerCase();
  // 検索結果初期化
  searchResult.innerHTML = "";
  // 検索結果表示
  searchRender(word);

  //サジェスト初期化
  suggestion.innerHTML = "";
  //入力欄に文字列があるなら
  if (word) {
    //キーワード取得
    const filtered = keyWords.filter((k) => k.toLowerCase().includes(word));
    //データ繰り返し
    filtered.forEach((item) => {
      //サジェスト作成
      const li = document.createElement("li");
      //サジェスト文字列追加
      li.textContent = item;
      //クリックイベント追加
      li.addEventListener("click", () => {
        //サジェストクリック時に入力欄に追加
        searchInput.value = item;
        //サジェスト非表示
        suggestion.style.display = "none";
        //検索結果表示
        searchRender(item);
      });
      //サジェスト要素追加
      suggestion.appendChild(li);
    });
    //キーワードがないならサジェストを表示しない
    suggestion.style.display = filtered.length > 0 ? "block" : "none";
  } else {
    //サジェスト非表示
    suggestion.style.display = "none";
  }
});

// カテゴリで検索機能
categoryBtn.forEach(function (button) {
  button.addEventListener("click", function (index) {
    //選択カテゴリ取得
    const word = button.dataset.category;
    // 検索結果初期化
    searchResult.innerHTML = "";
    //検索結果表示
    searchRender(word);
  });
});

// 検索結果一覧表示
function searchRender(word) {
  //検索結果初期化
  searchResult.innerHTML = "";
  // ヒット数
  let hitCount = 0;
  // データ繰り返し
  pages.forEach(function (page) {
    // タイトル検索
    const titleHit = page.title.toLowerCase().includes(word);

    // カテゴリ検索
    const categoryHit = page.category.includes(word);

    // ヒットしたなら表示
    if (titleHit || categoryHit) {
      // div生成
      const newDiv = document.createElement("div");
      newDiv.classList.add("result-div");
      // aタグ生成
      const newA = document.createElement("a");
      newA.href = page.url;
      newA.textContent = page.title;

      //imgタグ生成
      const newImg = document.createElement("img");
      //画像もjsonでアドレス指定する
      //newImg.src = page.image_url;
      newImg.alt = `${page.title}画像`;
      //pタグ生成
      const newP = document.createElement("p");
      //説明文字列
      newP.textContent = page.explanation;

      //aに追加
      newA.appendChild(newImg);
      newA.appendChild(newP);
      // divに追加
      newDiv.appendChild(newA);
      // 画面に追加
      searchResult.appendChild(newDiv);
      // 件数追加
      hitCount++;
    }
  });

  // 検索結果なし
  if (hitCount === 0) {
    const newP = document.createElement("p");
    newP.textContent = "検索結果はありません";
    searchResult.appendChild(newP);
  }

  // 件数表示
  searchResultNum.textContent = `${hitCount}件ヒットしました`;
}
