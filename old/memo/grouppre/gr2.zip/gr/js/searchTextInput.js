//文字データ読み込み
export let pages = [];
export let keyWords = [];

fetch("searchList.json")
  .then(function (response) {
    return response.json();
  })
  .then(function (data) {
    pages = data;
    keyWords = data.map((page) => page.title);
  });
